"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  BarChart3,
  Package,
  ShoppingCart,
  Users,
  Settings,
  LifeBuoy,
  LogOut,
  FlaskConical,
  Tag,
  FileText,
  Truck,
} from "lucide-react"
import { useState } from "react"

const sidebarNavItems = [
  {
    title: "Dashboard",
    href: "/",
    icon: BarChart3,
  },
  {
    title: "Products",
    href: "/products",
    icon: Package,
    subItems: [
      {
        title: "All Products",
        href: "/products",
      },
      {
        title: "Categories",
        href: "/categories",
      },
      {
        title: "Inventory",
        href: "/inventory",
      },
    ],
  },
  {
    title: "Orders",
    href: "/orders",
    icon: ShoppingCart,
    subItems: [
      {
        title: "All Orders",
        href: "/orders",
      },
      {
        title: "Shipping",
        href: "/shipping",
        icon: Truck,
      },
      {
        title: "Invoices",
        href: "/invoices",
        icon: FileText,
      },
    ],
  },
  {
    title: "Customers",
    href: "/customers",
    icon: Users,
  },
  {
    title: "Marketing",
    href: "/marketing",
    icon: Tag,
  },
  {
    title: "Reports",
    href: "/reports",
    icon: BarChart3,
  },
  {
    title: "Settings",
    href: "/settings",
    icon: Settings,
  },
]

export function Sidebar() {
  const pathname = usePathname()
  const [openItems, setOpenItems] = useState<string[]>([])

  const toggleItem = (title: string) => {
    if (openItems.includes(title)) {
      setOpenItems(openItems.filter((item) => item !== title))
    } else {
      setOpenItems([...openItems, title])
    }
  }

  return (
    <div className="hidden border-r bg-muted/40 lg:block lg:w-64">
      <div className="flex h-full flex-col gap-2">
        <div className="flex h-14 items-center border-b px-4">
          <Link href="/" className="flex items-center gap-2 font-semibold">
            <FlaskConical className="h-6 w-6 text-green-600" />
            <span>True Aminos</span>
          </Link>
        </div>
        <ScrollArea className="flex-1 px-2">
          <div className="space-y-1 py-2">
            {sidebarNavItems.map((item) => (
              <Button
                key={item.title}
                variant={pathname === item.href ? "secondary" : "ghost"}
                className={cn(
                  "w-full justify-start",
                  pathname === item.href
                    ? "bg-secondary text-secondary-foreground"
                    : "hover:bg-transparent hover:underline",
                )}
                asChild
              >
                <Link href={item.href}>
                  <item.icon className="mr-2 h-4 w-4" />
                  {item.title}
                </Link>
              </Button>
            ))}
          </div>
        </ScrollArea>
        <div className="mt-auto border-t p-4">
          <div className="flex flex-col gap-2">
            <Button variant="ghost" className="justify-start">
              <LifeBuoy className="mr-2 h-4 w-4" />
              Help & Support
            </Button>
            <Button variant="ghost" className="justify-start text-muted-foreground">
              <LogOut className="mr-2 h-4 w-4" />
              Log Out
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
