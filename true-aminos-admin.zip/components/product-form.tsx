"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { createProduct, updateProduct } from "@/lib/airtable"
import type { Product } from "@/lib/types"
import { Loader2, Plus, X } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const formSchema = z.object({
  name: z.string().min(2, {
    message: "Name must be at least 2 characters.",
  }),
  description: z.string().optional(),
  meta: z.string().optional(),
  slug: z.string().min(2, {
    message: "Slug must be at least 2 characters.",
  }),
  categoryId: z.string().min(1, {
    message: "Please select a category.",
  }),
  inStock: z.boolean().optional(),
  featured: z.boolean().optional(),
  outofstock: z.boolean().optional(),
  // Price fields are optional strings
  price5mg: z.string().optional(),
  price10mg: z.string().optional(),
  price2mg: z.string().optional(),
  price750mg: z.string().optional(),
  price100mg: z.string().optional(),
  price500mg: z.string().optional(),
  price20mg: z.string().optional(),
  price15mg: z.string().optional(),
  price30mg: z.string().optional(),
  price1mg: z.string().optional(),
  price600mg: z.string().optional(),
  price1500mg: z.string().optional(),
  price300mg: z.string().optional(),
  price5000mg: z.string().optional(),
  weights: z.string().min(1, {
    message: "At least one weight must be specified.",
  }),
})

interface ProductFormProps {
  product?: Product
}

export function ProductForm({ product }: ProductFormProps) {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [selectedWeights, setSelectedWeights] = useState<string[]>([])

  useEffect(() => {
    // Initialize selected weights from product if available
    if (product?.weights && typeof product.weights === "string") {
      setSelectedWeights(product.weights.split(","))
    }
  }, [product])

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: product?.name || "",
      description: product?.description || "",
      meta: product?.meta || "",
      slug: product?.slug || "",
      categoryId: product?.categoryId || "1",
      inStock: product?.inStock === "checked",
      featured: product?.featured === "checked",
      outofstock: product?.outofstock === "checked",
      // Price fields
      price5mg: product?.price5mg || "",
      price10mg: product?.price10mg || "",
      price2mg: product?.price2mg || "",
      price750mg: product?.price750mg || "",
      price100mg: product?.price100mg || "",
      price500mg: product?.price500mg || "",
      price20mg: product?.price20mg || "",
      price15mg: product?.price15mg || "",
      price30mg: product?.price30mg || "",
      price1mg: product?.price1mg || "",
      price600mg: product?.price600mg || "",
      price1500mg: product?.price1500mg || "",
      price300mg: product?.price300mg || "",
      price5000mg: product?.price5000mg || "",
      weights: product?.weights || "",
    },
  })

  const availableWeights = [
    "1mg",
    "2mg",
    "5mg",
    "10mg",
    "15mg",
    "20mg",
    "30mg",
    "100mg",
    "300mg",
    "500mg",
    "600mg",
    "750mg",
    "1500mg",
    "5000mg",
  ]

  const toggleWeight = (weight: string) => {
    let newSelectedWeights: string[]

    if (selectedWeights.includes(weight)) {
      newSelectedWeights = selectedWeights.filter((w) => w !== weight)
    } else {
      newSelectedWeights = [...selectedWeights, weight]
    }

    setSelectedWeights(newSelectedWeights)

    // Update the weights field in the form
    form.setValue("weights", newSelectedWeights.join(","))
  }

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsSubmitting(true)
    try {
      // Convert boolean values to "checked" or ""
      const formattedValues = {
        ...values,
        inStock: values.inStock ? "checked" : "",
        featured: values.featured ? "checked" : "",
        outofstock: values.outofstock ? "checked" : "",
      }

      if (product) {
        await updateProduct(product.id, formattedValues)
      } else {
        await createProduct(formattedValues)
      }
      router.push("/products")
      router.refresh()
    } catch (error) {
      console.error("Error saving product:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <Tabs defaultValue="basic" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="basic">Basic Information</TabsTrigger>
            <TabsTrigger value="pricing">Pricing & Weights</TabsTrigger>
            <TabsTrigger value="meta">Meta & SEO</TabsTrigger>
          </TabsList>

          <TabsContent value="basic" className="space-y-6 pt-4">
            <div className="grid gap-6 md:grid-cols-2">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Product Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter product name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="slug"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Slug</FormLabel>
                    <FormControl>
                      <Input placeholder="product-slug" {...field} />
                    </FormControl>
                    <FormDescription>Used in the URL: trueaminos.com/products/[slug]</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Enter product description" className="min-h-[120px]" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="categoryId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="1">Peptides</SelectItem>
                      <SelectItem value="2">Research Compounds</SelectItem>
                      <SelectItem value="3">Amino Acids</SelectItem>
                      <SelectItem value="4">Accessories</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid gap-6 md:grid-cols-3">
              <FormField
                control={form.control}
                name="inStock"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">In Stock</FormLabel>
                      <FormDescription>Product is available for purchase</FormDescription>
                    </div>
                    <FormControl>
                      <Switch checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="featured"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Featured</FormLabel>
                      <FormDescription>Show on homepage and featured sections</FormDescription>
                    </div>
                    <FormControl>
                      <Switch checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="outofstock"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Temporarily Out of Stock</FormLabel>
                      <FormDescription>Mark as temporarily unavailable</FormDescription>
                    </div>
                    <FormControl>
                      <Switch checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>
          </TabsContent>

          <TabsContent value="pricing" className="space-y-6 pt-4">
            <div>
              <h3 className="text-lg font-medium mb-2">Available Weights</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Select the weights this product is available in. You'll need to set prices for each selected weight.
              </p>

              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2 mb-6">
                {availableWeights.map((weight) => (
                  <Button
                    key={weight}
                    type="button"
                    variant={selectedWeights.includes(weight) ? "default" : "outline"}
                    className={selectedWeights.includes(weight) ? "bg-green-600 hover:bg-green-700" : ""}
                    onClick={() => toggleWeight(weight)}
                  >
                    {weight}
                    {selectedWeights.includes(weight) ? (
                      <X className="ml-2 h-4 w-4" />
                    ) : (
                      <Plus className="ml-2 h-4 w-4" />
                    )}
                  </Button>
                ))}
              </div>

              <FormField
                control={form.control}
                name="weights"
                render={({ field }) => (
                  <FormItem className="hidden">
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-medium">Pricing</h3>
              <p className="text-sm text-muted-foreground">
                Set prices for each selected weight. Only the prices for selected weights will be saved.
              </p>

              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {selectedWeights.map((weight) => {
                  const fieldName = `price${weight}` as keyof z.infer<typeof formSchema>
                  return (
                    <FormField
                      key={weight}
                      control={form.control}
                      name={fieldName}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Price for {weight}</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <span className="absolute left-3 top-2.5 text-muted-foreground">$</span>
                              <Input type="text" className="pl-7" {...field} />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )
                })}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="meta" className="space-y-6 pt-4">
            <FormField
              control={form.control}
              name="meta"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Meta Description</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Enter meta description for SEO" className="min-h-[100px]" {...field} />
                  </FormControl>
                  <FormDescription>
                    This description appears in search engine results. Keep it under 160 characters for best results.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </TabsContent>
        </Tabs>

        <div className="flex justify-end gap-4">
          <Button type="button" variant="outline" onClick={() => router.push("/products")} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {product ? "Update Product" : "Create Product"}
          </Button>
        </div>
      </form>
    </Form>
  )
}
