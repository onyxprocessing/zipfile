"use client"

import { useState } from "react"
import {
  Bell,
  Menu,
  Search,
  X,
  FlaskConical,
  BarChart3,
  Package,
  ShoppingCart,
  Users,
  Settings,
  Tag,
  FileText,
  Truck,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

// Add the sidebar navigation items
const sidebarNavItems = [
  {
    title: "Dashboard",
    href: "/",
    icon: BarChart3,
  },
  {
    title: "Products",
    href: "/products",
    icon: Package,
    subItems: [
      {
        title: "All Products",
        href: "/products",
      },
      {
        title: "Categories",
        href: "/categories",
      },
      {
        title: "Inventory",
        href: "/inventory",
      },
    ],
  },
  {
    title: "Orders",
    href: "/orders",
    icon: ShoppingCart,
    subItems: [
      {
        title: "All Orders",
        href: "/orders",
      },
      {
        title: "Shipping",
        href: "/shipping",
        icon: Truck,
      },
      {
        title: "Invoices",
        href: "/invoices",
        icon: FileText,
      },
    ],
  },
  {
    title: "Customers",
    href: "/customers",
    icon: Users,
  },
  {
    title: "Marketing",
    href: "/marketing",
    icon: Tag,
  },
  {
    title: "Reports",
    href: "/reports",
    icon: BarChart3,
  },
  {
    title: "Settings",
    href: "/settings",
    icon: Settings,
  },
]

export function Header() {
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const [openItems, setOpenItems] = useState<string[]>([])
  const pathname = usePathname()
  const [isOpen, setIsOpen] = useState(false)

  const toggleItem = (title: string) => {
    if (openItems.includes(title)) {
      setOpenItems(openItems.filter((item) => item !== title))
    } else {
      setOpenItems([...openItems, title])
    }
  }

  return (
    <header className="sticky top-0 z-10 flex h-14 items-center gap-4 border-b bg-background px-4 lg:h-[60px] lg:px-6">
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild>
          <Button variant="outline" size="icon" className="lg:hidden">
            <Menu className="h-5 w-5" />
            <span className="sr-only">Toggle Menu</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="lg:hidden">
          <div className="flex h-14 items-center border-b px-4">
            <Link href="/" className="flex items-center gap-2 font-semibold">
              <FlaskConical className="h-6 w-6 text-green-600" />
              <span>True Aminos</span>
            </Link>
          </div>
          <div className="py-4">
            <div className="space-y-1 py-2">
              {sidebarNavItems.map((item) => (
                <Button
                  key={item.title}
                  variant={pathname === item.href ? "secondary" : "ghost"}
                  className={cn(
                    "w-full justify-start",
                    pathname === item.href
                      ? "bg-secondary text-secondary-foreground"
                      : "hover:bg-transparent hover:underline",
                  )}
                  onClick={() => setIsOpen(false)}
                  asChild
                >
                  <Link href={item.href}>
                    <item.icon className="mr-2 h-4 w-4" />
                    {item.title}
                  </Link>
                </Button>
              ))}
            </div>
          </div>
        </SheetContent>
      </Sheet>

      <div className="w-full flex-1">
        {isSearchOpen ? (
          <div className="flex items-center gap-2">
            <Input type="search" placeholder="Search..." className="h-9 md:w-[300px] lg:w-[400px]" />
            <Button variant="ghost" size="icon" onClick={() => setIsSearchOpen(false)}>
              <X className="h-5 w-5" />
              <span className="sr-only">Close search</span>
            </Button>
          </div>
        ) : (
          <Button
            variant="outline"
            size="sm"
            className="h-9 justify-start text-muted-foreground md:w-[300px] lg:w-[400px]"
            onClick={() => setIsSearchOpen(true)}
          >
            <Search className="mr-2 h-4 w-4" />
            Search...
          </Button>
        )}
      </div>

      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon">
          <Bell className="h-5 w-5" />
          <span className="sr-only">Notifications</span>
        </Button>
        <Avatar>
          <AvatarImage src="/placeholder-user.jpg" alt="Admin" />
          <AvatarFallback>TA</AvatarFallback>
        </Avatar>
      </div>
    </header>
  )
}
