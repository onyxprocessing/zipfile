"use client"

import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend } from "recharts"

const data = [
  {
    name: "Jan",
    peptides: 1800,
    compounds: 1200,
    accessories: 400,
  },
  {
    name: "Feb",
    peptides: 2200,
    compounds: 1400,
    accessories: 500,
  },
  {
    name: "Mar",
    peptides: 2800,
    compounds: 1600,
    accessories: 600,
  },
  {
    name: "Apr",
    peptides: 2400,
    compounds: 1500,
    accessories: 550,
  },
  {
    name: "May",
    peptides: 3200,
    compounds: 1800,
    accessories: 700,
  },
  {
    name: "Jun",
    peptides: 3800,
    compounds: 2000,
    accessories: 800,
  },
  {
    name: "Jul",
    peptides: 4200,
    compounds: 2200,
    accessories: 850,
  },
  {
    name: "Aug",
    peptides: 3600,
    compounds: 1900,
    accessories: 750,
  },
  {
    name: "Sep",
    peptides: 4000,
    compounds: 2100,
    accessories: 800,
  },
  {
    name: "Oct",
    peptides: 4400,
    compounds: 2300,
    accessories: 900,
  },
  {
    name: "Nov",
    peptides: 4800,
    compounds: 2500,
    accessories: 950,
  },
  {
    name: "Dec",
    peptides: 5200,
    compounds: 2700,
    accessories: 1000,
  },
]

export function Overview() {
  return (
    <ResponsiveContainer width="100%" height={350}>
      <BarChart data={data}>
        <XAxis dataKey="name" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
        <YAxis
          stroke="#888888"
          fontSize={12}
          tickLine={false}
          axisLine={false}
          tickFormatter={(value) => `$${value}`}
        />
        <Tooltip formatter={(value) => [`$${value}`, ""]} cursor={{ fill: "rgba(0, 0, 0, 0.05)" }} />
        <Legend />
        <Bar dataKey="peptides" name="Peptides" fill="#16a34a" radius={[4, 4, 0, 0]} />
        <Bar dataKey="compounds" name="Research Compounds" fill="#2563eb" radius={[4, 4, 0, 0]} />
        <Bar dataKey="accessories" name="Accessories" fill="#d97706" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  )
}
