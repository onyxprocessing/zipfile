"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { formatCurrency, formatDate } from "@/lib/utils"
import Link from "next/link"

const recentOrders = [
  {
    id: "ord_1",
    customer: {
      name: "John Smith",
      email: "john@example.com",
      avatar: "/placeholder-user.jpg",
    },
    status: "completed",
    date: "2023-05-10T14:30:00",
    total: 129.99,
  },
  {
    id: "ord_2",
    customer: {
      name: "Sarah Johnson",
      email: "sarah@example.com",
      avatar: "/placeholder-user.jpg",
    },
    status: "processing",
    date: "2023-05-09T11:20:00",
    total: 79.95,
  },
  {
    id: "ord_3",
    customer: {
      name: "Michael Brown",
      email: "michael@example.com",
      avatar: "/placeholder-user.jpg",
    },
    status: "completed",
    date: "2023-05-08T16:45:00",
    total: 249.5,
  },
  {
    id: "ord_4",
    customer: {
      name: "Emily Davis",
      email: "emily@example.com",
      avatar: "/placeholder-user.jpg",
    },
    status: "shipped",
    date: "2023-05-07T09:15:00",
    total: 149.99,
  },
  {
    id: "ord_5",
    customer: {
      name: "David Wilson",
      email: "david@example.com",
      avatar: "/placeholder-user.jpg",
    },
    status: "processing",
    date: "2023-05-06T13:40:00",
    total: 89.95,
  },
]

const statusColors = {
  completed: "bg-green-500",
  processing: "bg-blue-500",
  shipped: "bg-yellow-500",
  cancelled: "bg-red-500",
}

export function RecentOrders() {
  return (
    <ScrollArea className="h-[350px]">
      <div className="space-y-4">
        {recentOrders.map((order) => (
          <Link
            key={order.id}
            href={`/orders/${order.id}`}
            className="flex items-center justify-between space-x-4 rounded-md border p-4 transition-colors hover:bg-muted/50"
          >
            <div className="flex items-center space-x-4">
              <Avatar>
                <AvatarImage src={order.customer.avatar || "/placeholder.svg"} alt={order.customer.name} />
                <AvatarFallback>{order.customer.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <p className="text-sm font-medium leading-none">{order.customer.name}</p>
                <p className="text-sm text-muted-foreground">{order.customer.email}</p>
              </div>
            </div>
            <div className="flex flex-col items-end">
              <p className="text-sm font-medium">{formatCurrency(order.total)}</p>
              <div className="flex items-center gap-2">
                <div className={`h-2 w-2 rounded-full ${statusColors[order.status as keyof typeof statusColors]}`} />
                <p className="text-xs capitalize text-muted-foreground">{order.status}</p>
              </div>
              <p className="text-xs text-muted-foreground">{formatDate(order.date)}</p>
            </div>
          </Link>
        ))}
      </div>
    </ScrollArea>
  )
}
