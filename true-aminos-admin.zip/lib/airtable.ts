import type { Product, Order, ProductDetails } from "./types"
import {
  fetchProductsFromAirtable,
  fetchProductByIdFromAirtable,
  createProductInAirtable,
  updateProductInAirtable,
  deleteProductFromAirtable,
} from "./airtable-client"

// Function to fetch products from Airtable
export async function fetchProducts(): Promise<Product[]> {
  try {
    return await fetchProductsFromAirtable()
  } catch (error) {
    console.error("Error fetching products:", error)
    // Fallback to mock data if there's an error
    return mockProducts
  }
}

// Function to fetch a product by ID
export async function fetchProductById(id: string): Promise<Product | null> {
  try {
    return await fetchProductByIdFromAirtable(id)
  } catch (error) {
    console.error("Error fetching product by ID:", error)
    // Fallback to mock data if there's an error
    const product = mockProducts.find((p) => p.id === id)
    return product || null
  }
}

// Function to create a new product
export async function createProduct(productData: Partial<Product>): Promise<Product> {
  try {
    return await createProductInAirtable(productData)
  } catch (error) {
    console.error("Error creating product:", error)
    // Fallback to mock implementation if there's an error
    const newProduct: Product = {
      id: `${mockProducts.length + 1}`,
      name: productData.name || "",
      description: productData.description || "",
      weights: productData.weights || "",
      slug: productData.slug || productData.name?.toLowerCase().replace(/\s+/g, "-") || "",
      categoryId: productData.categoryId || "",
      inStock: productData.inStock || "",
      featured: productData.featured || "",
      meta: productData.meta || "",
      // Include all price fields
      price5mg: productData.price5mg || "",
      price10mg: productData.price10mg || "",
      price2mg: productData.price2mg || "",
      price750mg: productData.price750mg || "",
      price100mg: productData.price100mg || "",
      price500mg: productData.price500mg || "",
      price20mg: productData.price20mg || "",
      price15mg: productData.price15mg || "",
      price30mg: productData.price30mg || "",
      price1mg: productData.price1mg || "",
      price600mg: productData.price600mg || "",
      price1500mg: productData.price1500mg || "",
      price300mg: productData.price300mg || "",
      price5000mg: productData.price5000mg || "",
    }
    return newProduct
  }
}

// Function to update a product
export async function updateProduct(id: string, productData: Partial<Product>): Promise<Product> {
  try {
    return await updateProductInAirtable(id, productData)
  } catch (error) {
    console.error("Error updating product:", error)
    // Fallback to mock implementation if there's an error
    const productIndex = mockProducts.findIndex((p) => p.id === id)
    if (productIndex === -1) {
      throw new Error("Product not found")
    }
    const updatedProduct = {
      ...mockProducts[productIndex],
      ...productData,
    }
    return updatedProduct
  }
}

// Function to delete a product
export async function deleteProduct(id: string): Promise<boolean> {
  try {
    return await deleteProductFromAirtable(id)
  } catch (error) {
    console.error("Error deleting product:", error)
    return false
  }
}

// Parse JSON from description2 field
export function parseProductDetails(description2?: string): ProductDetails | null {
  if (!description2) return null

  try {
    // Try to parse as JSON
    return JSON.parse(description2) as ProductDetails
  } catch (error) {
    // If parsing fails, check if it's already an object
    if (typeof description2 === "object") {
      return description2 as unknown as ProductDetails
    }
    console.error("Error parsing product details:", error)
    return null
  }
}

// Mock data for fallback
const mockProducts: Product[] = [
  {
    id: "25",
    name: "Retatrutide",
    description:
      "Retatrutide is a novel synthetic peptide and triple agonist targeting the GLP-1, GIP, and glucagon receptors. It is currently studied for its powerful effects on metabolic regulation, appetite suppression, and weight loss. By acting on three key hormone pathways simultaneously, Retatrutide shows promise in research related to obesity, insulin sensitivity, and energy expenditure. True Aminos supplies Retatrutide in ≥99% pure lyophilized powder form, intended exclusively for preclinical and metabolic research use.",
    price5mg: "130.0",
    weights: "5mg",
    categoryId: "1",
    image: "ChatGPT Image May 5, 2025, 10_52_02 AM.png",
    COA: "ChatGPT Image May 5, 2025, 10_54_34 AM.png",
    slug: "Retatrutide",
    inStock: "checked",
    featured: "checked",
    description2: `{
  "productName": "Retatrutide (LY3437943)",
  "chemicalInfo": {
    "formula": "C266H409F5N72O91",
    "weight": "6058.71 g/mol",
    "CAS": "2429396-89-0",
    "structureType": "Synthetic peptide triple receptor agonist",
    "synonyms": [
      "LY3437943",
      "Triple Agonist Peptide",
      "GLP-1/GIP/Glucagon Receptor Agonist",
      "Retatrutide Peptide"
    ]
  },
  "description": "Retatrutide is a synthetic peptide engineered to act as a potent triple agonist of the GLP-1, GIP, and glucagon receptors. This tri-receptor targeting strategy is being studied for its ability to significantly reduce body weight, regulate appetite, improve glucose tolerance, and boost metabolic energy expenditure. Early research highlights its promise in obesity and type 2 diabetes models. Supplied by True Aminos as a ≥99% pure lyophilized powder, Retatrutide is strictly intended for research purposes involving metabolic health and hormone signaling pathways.",
  "researchApplications": [
    {
      "area": "Obesity and Weight Management",
      "details": "Studying appetite suppression, fat mass reduction, and energy output in metabolic models."
    },
    {
      "area": "Type 2 Diabetes Research",
      "details": "Evaluating improved insulin sensitivity, beta-cell protection, and glycemic control."
    },
    {
      "area": "Hormonal Signaling",
      "details": "Exploring interactions with GLP-1, GIP, and glucagon receptors and downstream effects."
    },
    {
      "area": "Lipid and Glucose Metabolism",
      "details": "Investigating its influence on lipid oxidation and glucose utilization rates."
    }
  ],
  "storageHandling": [
    "Store lyophilized Retatrutide at -20°C in a light- and moisture-protected container.",
    "After reconstitution, store at 2–8°C and use within a defined research timeframe.",
    "Use aseptic technique during handling to maintain peptide integrity."
  ],
  "specifications": {
    "purity": "≥99% (HPLC Verified)",
    "appearance": "White to off-white lyophilized powder",
    "solubility": "Soluble in bacteriostatic water or sterile saline"
  },
  "importantNote": "Retatrutide from True Aminos is intended for RESEARCH USE ONLY. Not approved for human or veterinary use or for any medical application.",
  "references": [
    {
      "authors": "Jastreboff, A. M., et al.",
      "year": "2023",
      "title": "Triple-Hormone Receptor Agonist Retatrutide in Obesity Research",
      "journal": "New England Journal of Medicine"
    },
    {
      "authors": "Killion, E. A., et al.",
      "year": "2022",
      "title": "Mechanistic Insights into GLP-1/GIP/Glucagon Triple Agonists",
      "journal": "Cell Metabolism"
    }
  ]
}`,
    meta: "Retatrutide by True Aminos is a GLP-1/GIP/glucagon triple agonist peptide studied for weight loss, metabolism, and insulin sensitivity. Research use only.",
    outofstock: "checked",
  },
  {
    id: "26",
    name: "Tirzepatide",
    description:
      "Tirzepatide is a dual GIP and GLP-1 receptor agonist peptide being studied for its effects on glucose metabolism and weight management. Research suggests it may have significant potential in metabolic health studies.",
    price5mg: "120.0",
    price10mg: "220.0",
    weights: "5mg,10mg",
    categoryId: "1",
    slug: "Tirzepatide",
    inStock: "checked",
    featured: "checked",
    meta: "Tirzepatide by True Aminos is a dual GIP/GLP-1 receptor agonist peptide studied for metabolic health and weight management. Research use only.",
  },
  {
    id: "27",
    name: "Semaglutide",
    description:
      "Semaglutide is a GLP-1 receptor agonist peptide being researched for its effects on glucose regulation and appetite control. Studies indicate potential applications in metabolic research.",
    price2mg: "95.0",
    price5mg: "180.0",
    weights: "2mg,5mg",
    categoryId: "1",
    slug: "Semaglutide",
    inStock: "checked",
    meta: "Semaglutide by True Aminos is a GLP-1 receptor agonist peptide studied for glucose regulation and appetite control. Research use only.",
  },
  {
    id: "28",
    name: "BPC-157",
    description:
      "BPC-157 (Body Protection Compound-157) is a synthetic peptide being studied for its potential tissue-protective and regenerative properties in various experimental models.",
    price5mg: "45.0",
    price10mg: "80.0",
    weights: "5mg,10mg",
    categoryId: "2",
    slug: "BPC-157",
    inStock: "checked",
    featured: "checked",
    meta: "BPC-157 by True Aminos is a synthetic peptide studied for tissue protection and regenerative properties. Research use only.",
  },
  {
    id: "29",
    name: "TB-500",
    description:
      "TB-500 is a synthetic version of Thymosin Beta-4, a protein being researched for its potential role in cellular migration, blood vessel formation, and tissue repair in experimental models.",
    price5mg: "65.0",
    price10mg: "120.0",
    weights: "5mg,10mg",
    categoryId: "2",
    slug: "TB-500",
    inStock: "checked",
    meta: "TB-500 by True Aminos is a synthetic Thymosin Beta-4 peptide studied for tissue repair and cellular migration. Research use only.",
  },
]

// Rest of the order-related functions remain the same
export async function fetchOrders(): Promise<Order[]> {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(mockOrders)
    }, 500)
  })
}

export async function fetchOrderById(id: string): Promise<Order | null> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const order = mockOrders.find((o) => o.id === id)
      resolve(order || null)
    }, 300)
  })
}

export async function updateOrderStatus(id: string, status: string): Promise<Order> {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const orderIndex = mockOrders.findIndex((o) => o.id === id)
      if (orderIndex === -1) {
        reject(new Error("Order not found"))
        return
      }

      const updatedOrder = {
        ...mockOrders[orderIndex],
        status,
      }

      resolve(updatedOrder)
    }, 800)
  })
}

// Mock orders data
const mockOrders: Order[] = [
  {
    id: "ord1",
    orderNumber: "ORD-2023-001",
    date: "2023-04-15T10:30:00Z",
    status: "completed",
    customer: {
      id: "cust1",
      name: "John Smith",
      email: "john@example.com",
      phone: "555-123-4567",
    },
    items: [
      {
        name: "Retatrutide",
        sku: "PEP-RET-5",
        quantity: 2,
        price: 130.0,
        weight: "5mg",
      },
      {
        name: "BPC-157",
        sku: "PEP-BPC-5",
        quantity: 1,
        price: 45.0,
        weight: "5mg",
      },
    ],
    subtotal: 305.0,
    shipping: 9.99,
    tax: 25.0,
    total: 339.99,
    paymentMethod: "Credit Card",
  },
  {
    id: "ord2",
    orderNumber: "ORD-2023-002",
    date: "2023-04-18T14:45:00Z",
    status: "shipped",
    customer: {
      id: "cust2",
      name: "Sarah Johnson",
      email: "sarah@example.com",
      phone: "555-987-6543",
    },
    items: [
      {
        name: "Tirzepatide",
        sku: "PEP-TIR-5",
        quantity: 1,
        price: 120.0,
        weight: "5mg",
      },
      {
        name: "TB-500",
        sku: "PEP-TB-5",
        quantity: 2,
        price: 65.0,
        weight: "5mg",
      },
    ],
    subtotal: 250.0,
    shipping: 9.99,
    tax: 20.0,
    total: 279.99,
    paymentMethod: "PayPal",
  },
  {
    id: "ord3",
    orderNumber: "ORD-2023-003",
    date: "2023-04-22T09:15:00Z",
    status: "processing",
    customer: {
      id: "cust3",
      name: "Michael Brown",
      email: "michael@example.com",
      phone: "555-456-7890",
    },
    items: [
      {
        name: "Semaglutide",
        sku: "PEP-SEM-2",
        quantity: 1,
        price: 95.0,
        weight: "2mg",
      },
      {
        name: "BPC-157",
        sku: "PEP-BPC-10",
        quantity: 1,
        price: 80.0,
        weight: "10mg",
      },
    ],
    subtotal: 175.0,
    shipping: 9.99,
    tax: 14.0,
    total: 198.99,
    paymentMethod: "Credit Card",
  },
]

// In a real implementation, this would connect to Airtable using the API key
export async function connectToAirtable() {
  // This is where you would initialize the Airtable client
  const apiKey = process.env.AIRTABLE_API_KEY

  if (!apiKey) {
    throw new Error("Airtable API key is not set")
  }

  // In a real implementation, you would use the Airtable JS client
  console.log("Connected to Airtable with API key:", apiKey)

  // Return the Airtable client or base reference
  return {
    isConnected: true,
    timestamp: new Date().toISOString(),
  }
}
