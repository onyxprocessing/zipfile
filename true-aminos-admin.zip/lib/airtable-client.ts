import Airtable from "airtable"
import type { Product } from "./types"

// Initialize Airtable client
export function initAirtable() {
  const apiKey = process.env.AIRTABLE_API_KEY

  if (!apiKey) {
    throw new Error("Airtable API key is not set")
  }

  return new Airtable({ apiKey })
}

// Function to fetch products from Airtable
export async function fetchProductsFromAirtable(): Promise<Product[]> {
  try {
    const airtable = initAirtable()
    // Replace with your actual base ID
    const base = airtable.base("app3XDDBbU0ZZDBiY")
    const records = await base("products").select().all()

    return records.map((record) => ({
      id: record.id,
      name: record.get("name") as string,
      description: record.get("description") as string,
      price5mg: record.get("price5mg") as string,
      price10mg: record.get("price10mg") as string,
      price2mg: record.get("price2mg") as string,
      price750mg: record.get("price750mg") as string,
      price100mg: record.get("price100mg") as string,
      price500mg: record.get("price500mg") as string,
      price20mg: record.get("price20mg") as string,
      price15mg: record.get("price15mg") as string,
      price30mg: record.get("price30mg") as string,
      price1mg: record.get("price1mg") as string,
      price600mg: record.get("price600mg") as string,
      price1500mg: record.get("price1500mg") as string,
      price300mg: record.get("price300mg") as string,
      price5000mg: record.get("price5000mg") as string,
      weights: record.get("weights") as string,
      categoryId: record.get("categoryId") as string,
      image: record.get("image") as string,
      COA: record.get("COA") as string,
      image3: record.get("image3") as string,
      slug: record.get("slug") as string,
      inStock: record.get("inStock") as string,
      featured: record.get("featured") as string,
      description2: record.get("description2") as string,
      meta: record.get("meta") as string,
      suppliercost: record.get("suppliercost") as string,
      outofstock: record.get("outofstock") as string,
    }))
  } catch (error) {
    console.error("Error fetching products from Airtable:", error)
    throw error
  }
}

// Function to fetch a single product by ID
export async function fetchProductByIdFromAirtable(id: string): Promise<Product | null> {
  try {
    const airtable = initAirtable()
    const base = airtable.base("app3XDDBbU0ZZDBiY")

    const record = await base("products").find(id)

    if (!record) return null

    return {
      id: record.id,
      name: record.get("name") as string,
      description: record.get("description") as string,
      price5mg: record.get("price5mg") as string,
      price10mg: record.get("price10mg") as string,
      price2mg: record.get("price2mg") as string,
      price750mg: record.get("price750mg") as string,
      price100mg: record.get("price100mg") as string,
      price500mg: record.get("price500mg") as string,
      price20mg: record.get("price20mg") as string,
      price15mg: record.get("price15mg") as string,
      price30mg: record.get("price30mg") as string,
      price1mg: record.get("price1mg") as string,
      price600mg: record.get("price600mg") as string,
      price1500mg: record.get("price1500mg") as string,
      price300mg: record.get("price300mg") as string,
      price5000mg: record.get("price5000mg") as string,
      weights: record.get("weights") as string,
      categoryId: record.get("categoryId") as string,
      image: record.get("image") as string,
      COA: record.get("COA") as string,
      image3: record.get("image3") as string,
      slug: record.get("slug") as string,
      inStock: record.get("inStock") as string,
      featured: record.get("featured") as string,
      description2: record.get("description2") as string,
      meta: record.get("meta") as string,
      suppliercost: record.get("suppliercost") as string,
      outofstock: record.get("outofstock") as string,
    }
  } catch (error) {
    console.error("Error fetching product from Airtable:", error)
    return null
  }
}

// Function to create a product in Airtable
export async function createProductInAirtable(productData: Partial<Product>): Promise<Product> {
  try {
    const airtable = initAirtable()
    const base = airtable.base("app3XDDBbU0ZZDBiY")

    const record = await base("products").create({
      name: productData.name || "",
      description: productData.description || "",
      price5mg: productData.price5mg || "",
      price10mg: productData.price10mg || "",
      price2mg: productData.price2mg || "",
      price750mg: productData.price750mg || "",
      price100mg: productData.price100mg || "",
      price500mg: productData.price500mg || "",
      price20mg: productData.price20mg || "",
      price15mg: productData.price15mg || "",
      price30mg: productData.price30mg || "",
      price1mg: productData.price1mg || "",
      price600mg: productData.price600mg || "",
      price1500mg: productData.price1500mg || "",
      price300mg: productData.price300mg || "",
      price5000mg: productData.price5000mg || "",
      weights: productData.weights || "",
      categoryId: productData.categoryId || "",
      slug: productData.slug || "",
      inStock: productData.inStock || "",
      featured: productData.featured || "",
      meta: productData.meta || "",
      outofstock: productData.outofstock || "",
    })

    return {
      id: record.id,
      name: record.get("name") as string,
      description: record.get("description") as string,
      price5mg: record.get("price5mg") as string,
      price10mg: record.get("price10mg") as string,
      price2mg: record.get("price2mg") as string,
      price750mg: record.get("price750mg") as string,
      price100mg: record.get("price100mg") as string,
      price500mg: record.get("price500mg") as string,
      price20mg: record.get("price20mg") as string,
      price15mg: record.get("price15mg") as string,
      price30mg: record.get("price30mg") as string,
      price1mg: record.get("price1mg") as string,
      price600mg: record.get("price600mg") as string,
      price1500mg: record.get("price1500mg") as string,
      price300mg: record.get("price300mg") as string,
      price5000mg: record.get("price5000mg") as string,
      weights: record.get("weights") as string,
      categoryId: record.get("categoryId") as string,
      image: record.get("image") as string,
      COA: record.get("COA") as string,
      image3: record.get("image3") as string,
      slug: record.get("slug") as string,
      inStock: record.get("inStock") as string,
      featured: record.get("featured") as string,
      description2: record.get("description2") as string,
      meta: record.get("meta") as string,
      suppliercost: record.get("suppliercost") as string,
      outofstock: record.get("outofstock") as string,
    }
  } catch (error) {
    console.error("Error creating product in Airtable:", error)
    throw error
  }
}

// Function to update a product in Airtable
export async function updateProductInAirtable(id: string, productData: Partial<Product>): Promise<Product> {
  try {
    const airtable = initAirtable()
    const base = airtable.base("app3XDDBbU0ZZDBiY")

    const record = await base("products").update(id, {
      name: productData.name,
      description: productData.description,
      price5mg: productData.price5mg,
      price10mg: productData.price10mg,
      price2mg: productData.price2mg,
      price750mg: productData.price750mg,
      price100mg: productData.price100mg,
      price500mg: productData.price500mg,
      price20mg: productData.price20mg,
      price15mg: productData.price15mg,
      price30mg: productData.price30mg,
      price1mg: productData.price1mg,
      price600mg: productData.price600mg,
      price1500mg: productData.price1500mg,
      price300mg: productData.price300mg,
      price5000mg: productData.price5000mg,
      weights: productData.weights,
      categoryId: productData.categoryId,
      slug: productData.slug,
      inStock: productData.inStock,
      featured: productData.featured,
      meta: productData.meta,
      outofstock: productData.outofstock,
    })

    return {
      id: record.id,
      name: record.get("name") as string,
      description: record.get("description") as string,
      price5mg: record.get("price5mg") as string,
      price10mg: record.get("price10mg") as string,
      price2mg: record.get("price2mg") as string,
      price750mg: record.get("price750mg") as string,
      price100mg: record.get("price100mg") as string,
      price500mg: record.get("price500mg") as string,
      price20mg: record.get("price20mg") as string,
      price15mg: record.get("price15mg") as string,
      price30mg: record.get("price30mg") as string,
      price1mg: record.get("price1mg") as string,
      price600mg: record.get("price600mg") as string,
      price1500mg: record.get("price1500mg") as string,
      price300mg: record.get("price300mg") as string,
      price5000mg: record.get("price5000mg") as string,
      weights: record.get("weights") as string,
      categoryId: record.get("categoryId") as string,
      image: record.get("image") as string,
      COA: record.get("COA") as string,
      image3: record.get("image3") as string,
      slug: record.get("slug") as string,
      inStock: record.get("inStock") as string,
      featured: record.get("featured") as string,
      description2: record.get("description2") as string,
      meta: record.get("meta") as string,
      suppliercost: record.get("suppliercost") as string,
      outofstock: record.get("outofstock") as string,
    }
  } catch (error) {
    console.error("Error updating product in Airtable:", error)
    throw error
  }
}

// Function to delete a product in Airtable
export async function deleteProductFromAirtable(id: string): Promise<boolean> {
  try {
    const airtable = initAirtable()
    const base = airtable.base("app3XDDBbU0ZZDBiY")

    await base("products").destroy(id)
    return true
  } catch (error) {
    console.error("Error deleting product from Airtable:", error)
    return false
  }
}
