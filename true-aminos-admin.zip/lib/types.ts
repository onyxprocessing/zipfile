export interface Product {
  id: string
  name: string
  description: string
  price5mg?: string
  price10mg?: string
  price2mg?: string
  price750mg?: string
  price100mg?: string
  price500mg?: string
  price20mg?: string
  price15mg?: string
  price30mg?: string
  price1mg?: string
  price600mg?: string
  price1500mg?: string
  price300mg?: string
  price5000mg?: string
  weights: string
  categoryId: string
  image?: string
  COA?: string
  image3?: string
  slug: string
  inStock?: string
  featured?: string
  description2?: string
  meta?: string
  suppliercost?: string
  outofstock?: string
}

export interface ProductDetails {
  productName: string
  chemicalInfo: {
    formula: string
    weight: string
    CAS: string
    structureType: string
    synonyms: string[]
  }
  description: string
  researchApplications: Array<{
    area: string
    details: string
  }>
  storageHandling: string[]
  specifications: {
    purity: string
    appearance: string
    solubility: string
  }
  importantNote: string
  references: Array<{
    authors: string
    year: string
    title: string
    journal: string
  }>
}

export interface Customer {
  id: string
  name: string
  email: string
  phone?: string
}

export interface OrderItem {
  name: string
  sku: string
  quantity: number
  price: number
  weight?: string
}

export interface Order {
  id: string
  orderNumber: string
  date: string
  status: string
  customer: Customer
  items: OrderItem[]
  subtotal: number
  shipping: number
  tax: number
  total: number
  paymentMethod: string
}
