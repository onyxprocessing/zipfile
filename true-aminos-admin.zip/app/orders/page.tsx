import { fetchOrders } from "@/lib/airtable"
import { OrdersTable } from "@/components/orders-table"

export default async function OrdersPage() {
  const orders = await fetchOrders()

  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-3xl font-bold">Orders</h1>
      <OrdersTable orders={orders} />
    </div>
  )
}
