import { fetchOrderById } from "@/lib/airtable"
import { OrderDetails } from "@/components/order-details"
import { notFound } from "next/navigation"

export default async function OrderDetailsPage({ params }: { params: { id: string } }) {
  const order = await fetchOrderById(params.id)

  if (!order) {
    notFound()
  }

  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-3xl font-bold">Order Details</h1>
      <OrderDetails order={order} />
    </div>
  )
}
