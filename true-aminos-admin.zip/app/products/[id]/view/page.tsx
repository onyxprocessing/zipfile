import { fetchProductById, parseProductDetails } from "@/lib/airtable"
import { notFound } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { ArrowLeft, FileText, FlaskRoundIcon as Flask, Microscope } from "lucide-react"
import Link from "next/link"

export default async function ProductDetailPage({ params }: { params: { id: string } }) {
  const product = await fetchProductById(params.id)

  if (!product) {
    notFound()
  }

  const productDetails = product.description2 ? parseProductDetails(product.description2) : null
  const weights = product.weights && typeof product.weights === "string" ? product.weights.split(",") : []

  // Helper function to get price for a specific weight
  const getPriceForWeight = (weight: string) => {
    const priceKey = `price${weight}` as keyof typeof product
    return product[priceKey] || "N/A"
  }

  // Determine stock status
  const isInStock = product.inStock === "checked"

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/products" className="text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" />
          </Link>
          <h1 className="text-3xl font-bold">{product.name}</h1>
          {product.featured === "checked" && (
            <Badge variant="outline" className="ml-2 bg-yellow-100 text-yellow-800 border-yellow-300">
              Featured
            </Badge>
          )}
        </div>
        <Link href={`/products/${product.id}`}>
          <Button variant="outline">Edit Product</Button>
        </Link>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Flask className="h-5 w-5" />
              Product Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-medium text-muted-foreground mb-1">Description</h3>
              <p className="text-sm">{product.description || "No description available."}</p>
            </div>

            <div>
              <h3 className="font-medium text-muted-foreground mb-1">Status</h3>
              <div className="flex gap-2">
                <Badge
                  variant={isInStock ? "default" : "secondary"}
                  className={isInStock ? "bg-green-500" : "bg-red-500"}
                >
                  {isInStock ? "In Stock" : "Out of Stock"}
                </Badge>
              </div>
            </div>

            <div>
              <h3 className="font-medium text-muted-foreground mb-1">Available Weights & Pricing</h3>
              {weights.length > 0 ? (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
                  {weights.map((weight) => (
                    <div key={weight} className="flex items-center justify-between p-2 border rounded-md">
                      <span className="font-medium">{weight}</span>
                      <span>${getPriceForWeight(weight)}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No weight information available.</p>
              )}
            </div>

            <div>
              <h3 className="font-medium text-muted-foreground mb-1">Meta Description</h3>
              <p className="text-sm text-muted-foreground">{product.meta || "No meta description provided."}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Info</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Product ID</h3>
              <p>{product.id}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Slug</h3>
              <p>{product.slug || "No slug defined"}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Category</h3>
              <p>
                {product.categoryId === "1" && "Peptides"}
                {product.categoryId === "2" && "Research Compounds"}
                {product.categoryId === "3" && "Amino Acids"}
                {product.categoryId === "4" && "Accessories"}
                {!product.categoryId && "Uncategorized"}
              </p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">Images</h3>
              <div className="mt-1 flex flex-wrap gap-2">
                {product.image && (
                  <div className="border rounded-md p-1 w-16 h-16 flex items-center justify-center bg-muted">
                    <FileText className="h-8 w-8 text-muted-foreground" />
                  </div>
                )}
                {product.COA && (
                  <div className="border rounded-md p-1 w-16 h-16 flex items-center justify-center bg-muted">
                    <FileText className="h-8 w-8 text-muted-foreground" />
                  </div>
                )}
                {!product.image && !product.COA && (
                  <p className="text-sm text-muted-foreground">No images available.</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {productDetails && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Microscope className="h-5 w-5" />
              Technical Information
            </CardTitle>
            <CardDescription>Detailed scientific information about {product.name}</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="chemical">Chemical Info</TabsTrigger>
                <TabsTrigger value="applications">Applications</TabsTrigger>
                <TabsTrigger value="storage">Storage & Handling</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-4 pt-4">
                <div>
                  <h3 className="font-medium mb-2">{productDetails.productName}</h3>
                  <p className="text-sm">{productDetails.description}</p>
                </div>
                <div>
                  <h3 className="font-medium mb-2">Important Note</h3>
                  <p className="text-sm text-red-600">{productDetails.importantNote}</p>
                </div>
              </TabsContent>

              <TabsContent value="chemical" className="pt-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <h3 className="font-medium mb-2">Chemical Properties</h3>
                    <ul className="space-y-2">
                      <li className="text-sm">
                        <span className="font-medium">Formula:</span> {productDetails.chemicalInfo.formula}
                      </li>
                      <li className="text-sm">
                        <span className="font-medium">Molecular Weight:</span> {productDetails.chemicalInfo.weight}
                      </li>
                      <li className="text-sm">
                        <span className="font-medium">CAS Number:</span> {productDetails.chemicalInfo.CAS}
                      </li>
                      <li className="text-sm">
                        <span className="font-medium">Structure Type:</span> {productDetails.chemicalInfo.structureType}
                      </li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Specifications</h3>
                    <ul className="space-y-2">
                      <li className="text-sm">
                        <span className="font-medium">Purity:</span> {productDetails.specifications.purity}
                      </li>
                      <li className="text-sm">
                        <span className="font-medium">Appearance:</span> {productDetails.specifications.appearance}
                      </li>
                      <li className="text-sm">
                        <span className="font-medium">Solubility:</span> {productDetails.specifications.solubility}
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="mt-4">
                  <h3 className="font-medium mb-2">Synonyms</h3>
                  <div className="flex flex-wrap gap-2">
                    {productDetails.chemicalInfo.synonyms.map((synonym, index) => (
                      <Badge key={index} variant="outline">
                        {synonym}
                      </Badge>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="applications" className="pt-4">
                <div className="space-y-4">
                  <h3 className="font-medium">Research Applications</h3>
                  <div className="grid gap-4 md:grid-cols-2">
                    {productDetails.researchApplications.map((app, index) => (
                      <Card key={index}>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-base">{app.area}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm">{app.details}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
                <div className="mt-6">
                  <h3 className="font-medium mb-2">References</h3>
                  <ul className="space-y-2">
                    {productDetails.references.map((ref, index) => (
                      <li key={index} className="text-sm">
                        {ref.authors} ({ref.year}). {ref.title}. <em>{ref.journal}</em>.
                      </li>
                    ))}
                  </ul>
                </div>
              </TabsContent>

              <TabsContent value="storage" className="pt-4">
                <div>
                  <h3 className="font-medium mb-2">Storage & Handling Instructions</h3>
                  <ul className="space-y-2">
                    {productDetails.storageHandling.map((instruction, index) => (
                      <li key={index} className="text-sm flex items-start gap-2">
                        <span className="text-green-600 font-bold">•</span>
                        <span>{instruction}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
